# Commands and evidence

All product checks target head `a255bf04e890842ceb629792428eef0b63ec24e7`. Commands use relative paths; `source` was a detached checkout of that exact head. `py314` and `py311` were isolated environments. Dependency inputs came from the committed hash-pinned requirement files.

- Full gate, both macOS and Ubuntu: `python3 scripts/verify-artifact.py ../artifact` from the frozen source; exit 0. Linux used the same command through `linux-gate.py`, writing `linux-artifact`.
- Supplemental Linux sequence: `python3 /evidence/linux-extra.py`; its subprocesses and outcomes are recorded by the included driver and logs. No product source is mounted writable into this container.
- Native lower-bound lane: `py311/bin/python -m pip check`; `py311/bin/python -m unittest discover -s source/tests -p test_completion.py -v`; both exit 0 after installing the current wheel.
- Native sdist lane: `py314/bin/python -m pip --isolated install --no-deps --no-build-isolation --force-reinstall artifact/uptible_cli-0.1.0.tar.gz`; then pip check and the same seven completion tests; all exit 0.
- Native interactive: `py314/bin/python verify-interactive.py py314/bin/uptible` and `py314/bin/python verify-function-shadow-pty.py py314/bin/uptible`; both exit 0, captured stderr empty.
- Native guards: `py314/bin/python verify-guarded.py`; exit 0, 18 results.
- Native trust boundary: `py314/bin/python verify-audit-boundary.py`; exit 0, three results, including an unsafe-policy positive control.
- Native fixture mutations: copied only `tests/test_completion.py` into separate control directories; replaced the one `compinit -i -D` with `compinit -D` or `compinit -u -D`. `python -m unittest discover -s CONTROL -p test_completion.py -v` exits 1 with 12 failures each; product source is unchanged.
- Source checks: `git rev-parse HEAD HEAD^{tree}`; `git diff --check BASE HEAD`; `git status --porcelain --untracked-files=all`; exact identity, diff check exit 0, clean status.

`Dockerfile` pins Ubuntu 26.04; installed distribution reports 26.04.1. Dependencies were downloaded from the public Python index under committed hashes. This network use concerns test tool/runtime installation, not completion queries. Do not publish the packet to a public repository if the source repository itself is private.
