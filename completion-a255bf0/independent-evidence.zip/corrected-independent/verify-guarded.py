import contextlib
import io
import json
import socket
import sys
from unittest.mock import patch

import keyring
import uptible_cli

calls = []


def forbidden(*args, **kwargs):
    calls.append('forbidden')
    raise AssertionError('guarded I/O or dispatch')


def query(args):
    with patch.object(sys, 'argv', ['uptible', *args]), contextlib.redirect_stdout(io.StringIO()) as output:
        result = uptible_cli.main()
    return result, output.getvalue()


results = []
with patch.object(uptible_cli, 'run', forbidden), patch.object(uptible_cli, 'Store', forbidden), \
     patch.object(uptible_cli, 'request', forbidden), patch.object(uptible_cli.webbrowser, 'open', forbidden), \
     patch.object(socket, 'socket', forbidden), patch.object(socket, 'create_connection', forbidden), \
     patch.object(keyring, 'get_keyring', forbidden), patch.object(keyring, 'get_password', forbidden), \
     patch.object(keyring, 'set_password', forbidden), patch.object(keyring, 'delete_password', forbidden):
    for shell in ('bash', 'zsh'):
        status, output = query(['completion', shell])
        assert status == 0 and '_uptible_complete' in output
        results.append({'case': 'generate-' + shell, 'status': status, 'passed': True})
    for args, status, expected in [
        (['--_complete', '4', 'uptible', '--profile', '$(touch marker)', 'auth', 'sta'], 0, 'status'),
        (['--_complete', '2', 'uptible', 'completion', 'z'], 0, 'zsh'),
        (['--_complete', '3', 'uptible', 'completion', '--', 'z'], 0, 'zsh'),
        (['--_complete', '2', 'uptible', '--credential-file', 'private-value'], 0, ''),
        (['--_complete', '1', 'uptible', 'n', *(['x'] * 255)], 2, ''),
        (['--_complete', '1', 'uptible', 'é' * 32769], 2, ''),
        (['--_complete-bash', '3', 'uptible ', 'extra'], 2, ''),
        (['--_complete-bash', '-1', 'uptible '], 2, ''),
        (['--_complete-bash', '999', 'uptible '], 2, ''),
    ]:
        actual = query(args)
        assert actual == (status, expected), (args[:2], actual)
        results.append({'case': 'query-' + str(len(results)), 'status': status, 'expected': expected, 'passed': True})
    line = "uptible --profile 'café ☕' auth sta --help"
    cursor = len(line.split(' --help')[0].encode())
    assert query(['--_complete-bash', str(cursor), line]) == (0, 'status')
    results.append({'case': 'Unicode-byte-cursor-before-suffix', 'passed': True})
    assert calls == []
    for name, invoke in [('dispatch', lambda: query(['account', 'show'])), ('socket', lambda: socket.socket()), ('keyring', lambda: keyring.get_password('synthetic', 'synthetic')), ('store', lambda: uptible_cli.Store()), ('browser', lambda: uptible_cli.webbrowser.open('https://example.invalid')), ('request', lambda: uptible_cli.request('https://example.invalid'))]:
        try:
            invoke()
        except AssertionError as error:
            assert str(error) == 'guarded I/O or dispatch'
            results.append({'case': 'guard-positive-' + name, 'passed': True})
        else:
            raise AssertionError('guard inactive: ' + name)
assert len(calls) == 6
print(json.dumps({'installed_module': uptible_cli.__file__, 'results': results}, indent=2))
