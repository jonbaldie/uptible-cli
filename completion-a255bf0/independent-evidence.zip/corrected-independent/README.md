# Corrected CLI29 independent evidence

Verdict and scope are in REVIEW.md. REPLAY.md describes commands. Logs retain expected failing controls; failures in those controls are intentional. The first Linux fixed-delay PTY failure is retained separately; the bounded-response driver passes and captures actual editor buffers.

Paths identifying the review workstation and temporary build directories are replaced with placeholders. Container paths in replay drivers are synthetic. Test values and invalid credential-file names are fixtures, not user data. There are no screenshots because these checks exercise a CLI. The current wheel and sdist are included under artifact/; Linux independently produced the same bytes in this run. Respect the source repository’s privacy when sharing.

SHA256SUMS covers every other file in this folder. No publication, production login or forge mutation was performed. Parent reviewer owns attachment upload and saved-body accessibility checks.
