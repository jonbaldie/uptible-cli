import json, os, pathlib, subprocess, sys
root=pathlib.Path('/evidence')
source=pathlib.Path('/home/runner/review-source')
def run(args,name):
    with (root/(name+'.log')).open('w') as output:
        result=subprocess.run(args,cwd=root,stdout=output,stderr=subprocess.STDOUT)
    if result.returncode: raise RuntimeError((name,result.returncode))
run(['uname','-a'],'extra-kernel')
run(['bash','--version'],'extra-bash')
run(['zsh','--version'],'extra-zsh')
run([sys.executable,'--version'],'extra-python')
run(['cat','/etc/os-release'],'extra-os')
run(['git','clone','/evidence/source.bundle',str(source)],'extra-clone')
run([sys.executable,'-m','venv','/home/runner/installed'],'extra-venv')
python='/home/runner/installed/bin/python'
run([python,'-m','pip','--isolated','install','--index-url','https://pypi.org/simple','--only-binary=:all:','--require-hashes','-r',str(source/'scripts/runtime-requirements.txt'),'-r',str(source/'scripts/verification-requirements.txt')],'extra-inputs')
run([python,'-m','pip','--isolated','install','--no-deps',str(root/'linux-artifact/uptible_cli-0.1.0-py3-none-any.whl')],'extra-wheel-install')
run([python,'-m','pip','check'],'extra-wheel-pipcheck')
run([python,'-m','unittest','discover','-s',str(source/'tests'),'-p','test_completion.py','-v'],'extra-wheel-completion')
for script in ['verify-interactive-bounded.py','verify-function-shadow-pty.py','verify-audit-boundary.py','verify-guarded.py']:
    args=[python,str(root/script)]
    if 'pty' in script or script=='verify-interactive-bounded.py': args.append('/home/runner/installed/bin/uptible')
    env=dict(os.environ,PATH='/home/runner/installed/bin:'+os.environ['PATH'])
    with (root/(script+'.json')).open('w') as out,(root/(script+'.stderr')).open('w') as err:
        result=subprocess.run(args,cwd=root,env=env,stdout=out,stderr=err)
    if result.returncode: raise RuntimeError((script,result.returncode))
run([python,'-m','pip','--isolated','install','--no-deps','--no-build-isolation','--force-reinstall',str(root/'linux-artifact/uptible_cli-0.1.0.tar.gz')],'extra-sdist-install')
run([python,'-m','pip','check'],'extra-sdist-pipcheck')
run([python,'-m','unittest','discover','-s',str(source/'tests'),'-p','test_completion.py','-v'],'extra-sdist-completion')
print(json.dumps({'all_commands_passed':True}))
