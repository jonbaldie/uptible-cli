#!/usr/bin/env python3
"""Exercise installed completion through real interactive shell editors."""
import fcntl
import json
import os
from pathlib import Path
import pty
import select
import shlex
import signal
import struct
import subprocess
import sys
import tempfile
import termios
import time

cli = Path(sys.argv[1]).resolve()
results = []


def read_for(fd, seconds):
    result = b''
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        if select.select([fd], [], [], max(0, deadline - time.monotonic()))[0]:
            try:
                chunk = os.read(fd, 65536)
            except OSError:
                break
            if not chunk:
                break
            result += chunk
    return result.decode(errors='replace')


cases = [('uptible no', 'uptible notifications'),
         ("uptible --credential-file '/does/not/exist/private.json' completion zs", "uptible --credential-file '/does/not/exist/private.json' completion zsh"),
         ("uptible notifications edit 17 --message 'x;$(touch marker)' --display-m", "uptible notifications edit 17 --message 'x;$(touch marker)' --display-maps-only")]

with tempfile.TemporaryDirectory() as temporary:
    tmp = Path(temporary)
    for shell in ('bash', 'zsh'):
        script = tmp / shell
        script.write_text(subprocess.check_output([cli, 'completion', shell], text=True))
        pid, fd = pty.fork()
        if pid == 0:
            os.chdir(tmp)
            os.environ.update(PATH=str(cli.parent) + os.pathsep + os.environ['PATH'], HOME=str(tmp),
                              TERM='dumb', BASH_SILENCE_DEPRECATION_WARNING='1')
            if shell == 'bash':
                os.execvp('bash', ['bash', '--noprofile', '--norc', '-i'])
            os.execvp('zsh', ['zsh', '-f', '-i'])
        try:
            fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack('HHHH', 24, 240, 0, 0))
            read_for(fd, 0.3)
            setup = "PS1='completion-test> '; "
            if shell == 'zsh':
                setup += 'autoload -Uz compinit; compinit -D; '
            setup += 'uptible() { printf invoked > marker; }; source ' + shlex.quote(str(script)) + '\n'
            os.write(fd, setup.encode())
            read_for(fd, 0.8)
            if shell == 'zsh':
                os.write(fd, b'capture() { print -r -- "BUFFER=$BUFFER"; BUFFER=""; zle reset-prompt; }; zle -N capture; bindkey "^X^V" capture\n')
                read_for(fd, 0.3)
            for typed, expected in cases:
                os.write(fd, (typed + '\t').encode())
                terminal = read_for(fd, 1.5)
                captured = ''
                if shell == 'zsh':
                    os.write(fd, b'\x18\x16')
                    captured = read_for(fd, 0.2)
                    passed = 'BUFFER=' + expected in captured
                else:
                    passed = expected in terminal
                    os.write(fd, b'\x15')
                    read_for(fd, 0.1)
                results.append({'shell': shell, 'typed': typed + '<Tab>', 'expected': expected,
                                'passed': passed, 'terminal_after_tab': terminal, 'captured_buffer': captured})
                if not passed:
                    raise AssertionError(results[-1])
            assert not (tmp / 'marker').exists(), 'Completion evaluated a literal value'
        finally:
            os.kill(pid, signal.SIGKILL)
            os.waitpid(pid, 0)
            os.close(fd)
print(json.dumps(results, indent=2))
