import subprocess,sys
from pathlib import Path
source=Path('/home/runner/review-source')
subprocess.run(['git','clone','/evidence/source.bundle',str(source)],check=True)
subprocess.run([sys.executable,'scripts/verify-artifact.py','/evidence/linux-artifact'],cwd=source,check=True)
