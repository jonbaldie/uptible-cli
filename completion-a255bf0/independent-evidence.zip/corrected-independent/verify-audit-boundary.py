import json,os,subprocess,tempfile
from pathlib import Path

results=[]
with tempfile.TemporaryDirectory() as temporary:
    root=Path(temporary)
    trusted=root/'trusted';untrusted=root/'untrusted'
    trusted.mkdir(mode=0o755);untrusted.mkdir();untrusted.chmod(0o777)
    (trusted/'_review_trusted').write_text('#compdef review-trusted\nprint trusted > "$REVIEW_TRUSTED_MARKER"\n')
    (untrusted/'_review_untrusted').write_text('#compdef review-untrusted\nprint untrusted > "$REVIEW_UNTRUSTED_MARKER"\n')
    default=subprocess.check_output(['zsh','-fc','print -rl -- $fpath'],text=True).splitlines()
    env=dict(os.environ,FPATH=os.pathsep.join([str(untrusted),str(trusted),*default]),REVIEW_TRUSTED_MARKER=str(root/'trusted-marker'),REVIEW_UNTRUSTED_MARKER=str(root/'untrusted-marker'))
    audit=subprocess.run(['zsh','-fc','autoload -Uz compaudit; compaudit'],env=env,capture_output=True,text=True)
    assert audit.returncode!=0 and str(untrusted) in audit.stdout.splitlines()
    assert str(trusted) not in audit.stdout.splitlines()
    results.append({'case':'real-compaudit-distinguishes-trusted-and-untrusted','passed':True})
    fixed=subprocess.run(['zsh','-fc','autoload -Uz compinit; compinit -i -D; [[ -z $_comps[review-untrusted] ]] || exit 11; [[ $_comps[review-trusted] == _review_trusted ]] || exit 12; [[ ${fpath[(Ie)$1]} == 0 ]] || exit 13; _review_trusted','review',str(untrusted)],env=env,capture_output=True,text=True)
    assert fixed.returncode==0 and fixed.stderr=='',fixed
    assert (root/'trusted-marker').read_text().strip()=='trusted'
    assert not (root/'untrusted-marker').exists()
    results.append({'case':'ignore-policy-excludes-unsafe-file-preserves-trusted-function','passed':True})
    unsafe=subprocess.run(['zsh','-fc','autoload -Uz compinit; compinit -u -D; [[ $_comps[review-untrusted] == _review_untrusted ]] || exit 14; _review_untrusted'],env=env,capture_output=True,text=True)
    assert unsafe.returncode==0 and unsafe.stderr=='',unsafe
    assert (root/'untrusted-marker').read_text().strip()=='untrusted'
    results.append({'case':'unsafe-policy-positive-control-registers-and-executes-unsafe-file','passed':True})
print(json.dumps({'results':results,'temporary_markers_removed':True},indent=2))
