# Independent completion evidence

Read REVIEW.md for the exact approval scope, artifact identities, commands, observations, and limits. This bundle preserves the original Zsh spacing expectation failure and its native-shell control. The reviewed artifact gate and all final behavior checks passed. No account command was executed in a PTY.

For replay, check out the head named in artifact/SOURCE_REVISION into source/. With Bash and Zsh available, create Python 3.11 and 3.14 environments. In each environment install hash-pinned runtime inputs from source/scripts/runtime-requirements.txt, then install the included wheel with --no-deps and run pip check. Run the completion suite outside source/:

```sh
python -m unittest discover -s source/tests -p test_completion.py -v
python verify-interactive.py /path/to/environment/bin/uptible
python verify-extra-pty.py /path/to/environment/bin/uptible
python verify-extra-pty.py /path/to/environment/bin/uptible --cursor-control
python verify-extra-pty.py /path/to/environment/bin/uptible --cursor-only
python verify-guarded.py
```

The final extra-PTY helper expects native Zsh spacing. The original extra-pty.json records the initial one-space expectation and its failure. The native compadd control confirms the two-space behavior. Local source, home, and temporary paths in logs are replaced with placeholders. The included distributions contain public client source and package metadata. SHA256SUMS.json covers every evidence file except itself.
