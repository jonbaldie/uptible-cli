import fcntl
import json
import os
from pathlib import Path
import pty
import select
import shlex
import signal
import struct
import subprocess
import sys
import tempfile
import termios
import time

cli = Path(sys.argv[1]).resolve()
results = []


def read_for(fd, seconds):
    data = b''
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        if select.select([fd], [], [], max(0, deadline - time.monotonic()))[0]:
            try:
                part = os.read(fd, 65536)
            except OSError:
                break
            if not part:
                break
            data += part
    return data.decode(errors='replace')


cases = [
    ("uptible --profile 'café ☕' auth sta", 'uptible --profile \'café ☕\' auth status', ''),
    ('uptible --profile space\\ value auth sta', 'uptible --profile space\\ value auth status', ''),
    ('uptible --profile=demo auth sta', 'uptible --profile=demo auth status', ''),
    ('uptible --profile="a:b=c" auth sta', 'uptible --profile="a:b=c" auth status', ''),
    ('uptible --pro demo auth sta', 'uptible --pro demo auth status', ''),
    ('uptible completion z', 'uptible completion zsh', ''),
    ('uptible completion -- z', 'uptible completion -- zsh', ''),
    ("uptible --profile '`touch marker`' auth sta", "uptible --profile '`touch marker`' auth status", ''),
    ('uptible auth sta --help', 'uptible auth status --help', '\x02' * 7),
    ("uptible --profile 'unfinished", "uptible --profile 'unfinished", ''),
    ('uptible --profile private-value', 'uptible --profile private-value', ''),
    ('uptible -- au', 'uptible -- au', ''),
]
mode = sys.argv[2] if len(sys.argv) > 2 else ''
if mode:
    cases = [cases[8]]
with tempfile.TemporaryDirectory() as temporary:
    tmp = Path(temporary)
    for shell in (('zsh',) if mode == '--cursor-control' else ('bash', 'zsh')):
        script = tmp / shell
        script.write_text(subprocess.check_output([cli, 'completion', shell], text=True))
        pid, fd = pty.fork()
        if pid == 0:
            os.chdir(tmp)
            os.environ.update(PATH=str(cli.parent) + os.pathsep + os.environ['PATH'], HOME=str(tmp), TERM='dumb', BASH_SILENCE_DEPRECATION_WARNING='1', LC_ALL='en_US.UTF-8')
            os.execvp(shell, [shell, '--noprofile', '--norc', '-i'] if shell == 'bash' else [shell, '-f', '-i'])
        try:
            fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack('HHHH', 24, 240, 0, 0))
            read_for(fd, .3)
            setup = "PS1='review> '; "
            if shell == 'zsh':
                setup += 'autoload -Uz compinit; compinit -D; '
            setup += 'source ' + shlex.quote(str(script)) + '\n'
            os.write(fd, setup.encode())
            read_for(fd, .8)
            if mode == '--cursor-control':
                os.write(fd, b'_uptible_complete() { compadd -- status; }\n')
                read_for(fd, .3)
            if shell == 'zsh':
                os.write(fd, b'capture() { print -r -- "BUFFER=$BUFFER"; BUFFER=""; zle reset-prompt; }; zle -N capture; bindkey "^X^V" capture\n')
                read_for(fd, .3)
            for typed, expected, movement in cases:
                if shell == 'zsh' and movement:
                    expected = expected.replace(' --help', '  --help')
                os.write(fd, (typed + movement + '\t').encode())
                terminal = read_for(fd, 1.5)
                if shell == 'zsh':
                    os.write(fd, b'\x18\x16')
                    captured = read_for(fd, .2)
                    actual = captured.split('BUFFER=', 1)[1].split('\r', 1)[0].rstrip() if 'BUFFER=' in captured else ''
                    passed = actual == expected
                else:
                    os.write(fd, b'\x0c')
                    captured = read_for(fd, .2)
                    passed = expected in captured
                    os.write(fd, b'\x01\x0b')
                    read_for(fd, .1)
                results.append(dict(shell=shell, typed=typed, cursor_left=len(movement), expected=expected, passed=passed, terminal=terminal, capture=captured))
            assert not (tmp / 'marker').exists(), 'literal profile value executed'
        finally:
            os.kill(pid, signal.SIGKILL)
            os.waitpid(pid, 0)
            os.close(fd)
print(json.dumps(results, indent=2, ensure_ascii=False))
sys.exit(0 if all(row['passed'] for row in results) else 1)
