# Reproduce the artifact checks

Use a clean checkout of the revision in `SOURCE_REVISION`. Use supported CPython 3.11 through 3.14 on macOS or Linux with Bash and Zsh installed. Run the repository gate from that checkout with an absent or empty output directory.

```sh
python scripts/verify-artifact.py ../verification-output
```

This builds committed source twice with pinned inputs, installs outside the checkout, runs synthetic tests, checks six negative controls, and records artifact and dependency identities. It does not enable the real-account integration suite.

From the extracted evidence packet, compare both recorded distributions and dependency manifests directly.

```sh
python verify-equivalence.py baseline . repeated-equivalence.json
```

To repeat the installed-wheel readback, use the same supported Python and create an empty directory first.

```sh
mkdir readback-output
python read-installed-wheel.py . runtime-requirements.txt readback-output
```

The readback installs pinned runtime inputs and the hash-checked final wheel into that directory. It checks the installed module bytes, metadata, dependency versions, CLI help, version, and conflicting cursors. Remove `readback-output` after reviewing its results.

`SHA256SUMS` covers the final distributions. `EVIDENCE_SHA256SUMS` covers every other evidence packet member. All evidence paths are relative to this packet. No live account, provider key, local machine link, or private agent session is needed to read it.
