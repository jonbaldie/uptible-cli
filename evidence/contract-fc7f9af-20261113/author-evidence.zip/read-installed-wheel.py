import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import venv


def main():
    artifacts, runtime_requirements, audit = map(lambda value: Path(value).resolve(), sys.argv[1:])
    manifest = json.loads((artifacts / 'BUILD_MANIFEST.json').read_text())
    wheel = next(artifacts.glob('*.whl'))
    expected = manifest['artifacts'][wheel.name]
    assert hashlib.sha256(wheel.read_bytes()).hexdigest() == expected
    env = {key: value for key, value in os.environ.items() if not key.startswith(('PYTHON', 'PIP_', 'UPTIBLE'))}
    env.update(PIP_CONFIG_FILE=os.devnull, BROWSER='/bin/false')
    work = audit / 'smoke-work'
    work.mkdir()
    envdir = audit / 'smoke-venv'
    venv.EnvBuilder(with_pip=True).create(envdir)
    python = envdir / 'bin/python'
    cli = envdir / 'bin/uptible'
    requirement = work / 'artifact.txt'
    requirement.write_text(f'{wheel.as_uri()} --hash=sha256:{expected}\n')
    with (audit / 'smoke-install.log').open('w') as log:
        for arguments in [
            ['install', '--require-hashes', '--only-binary=:all:', '-r', runtime_requirements],
            ['install', '--no-deps', '--require-hashes', '-r', requirement],
            ['check'],
        ]:
            subprocess.run([python, '-m', 'pip', *arguments], check=True, cwd=work, env=env, stdout=log, stderr=subprocess.STDOUT)
    inspect = '''import hashlib, importlib.metadata as m, json, sys
from pathlib import Path
import uptible_cli
p=Path(uptible_cli.__file__).resolve()
assert p.is_relative_to(Path(sys.prefix).resolve())
print(json.dumps({'module_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'version':m.version('uptible-cli'),'module_from_installed_venv':True,'dependencies':{name:m.version(name) for name in sys.argv[1:]}}))
'''
    names = [dependency['name'] for dependency in manifest['runtime_dependencies']]
    installed = json.loads(subprocess.check_output([python, '-c', inspect, *names], cwd=work, env=env, text=True))
    assert installed['module_sha256'] == manifest['module_sha256']
    assert installed['version'] == manifest['version']
    assert installed['dependencies'] == {dependency['name']: dependency['version'] for dependency in manifest['runtime_dependencies']}
    commands = []
    for arguments, code in [
        (['--version'], 0),
        (['--help'], 0),
        (['notifications', 'list', '--help'], 0),
        (['notifications', 'create', '--help'], 0),
        (['--json', 'notifications', 'list', '--after', '2', '--before', '9'], 2),
    ]:
        result = subprocess.run([cli, *arguments], cwd=work, env=env, text=True, capture_output=True)
        assert result.returncode == code, result
        commands.append({'command': ['uptible', *arguments], 'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr})
    assert commands[0]['stdout'] == 'uptible ' + manifest['version'] + '\n'
    assert '--before' in commands[2]['stdout'] and '--archived' in commands[2]['stdout']
    assert '--state {draft,active}' in commands[3]['stdout']
    assert 'not allowed with argument --after' in commands[4]['stderr']
    receipt = {'source_revision': manifest['source_revision'], 'wheel_sha256': expected, 'outside_checkout': True, 'installed': installed, 'commands': commands}
    (audit / 'installed-command-receipt.safe.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'source_revision': manifest['source_revision'], 'installed_module_sha256': installed['module_sha256'], 'commands': len(commands), 'outside_checkout': True}, indent=2))


if __name__ == '__main__':
    main()
