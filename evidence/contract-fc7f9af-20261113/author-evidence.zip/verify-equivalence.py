import ast
import hashlib
import json
from pathlib import Path
import sys
import tarfile
import zipfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def wheel_members(path):
    with zipfile.ZipFile(path) as archive:
        assert len(archive.namelist()) == len(set(archive.namelist()))
        assert archive.testzip() is None
        return {name: archive.read(name) for name in archive.namelist()}


def wheel_metadata_changes(old_path, new_path):
    fields = ['filename', 'date_time', 'compress_type', 'comment', 'extra', 'create_system', 'create_version', 'extract_version', 'reserved', 'flag_bits', 'volume', 'internal_attr', 'external_attr', 'header_offset', 'CRC', 'compress_size', 'file_size']
    with zipfile.ZipFile(old_path) as old, zipfile.ZipFile(new_path) as new:
        assert old.comment == new.comment
        changes = {name: [field for field in fields if getattr(old.getinfo(name), field) != getattr(new.getinfo(name), field)] for name in old.namelist()}
    assert all(fields == ['date_time'] for fields in changes.values())
    return changes


def source_members(path):
    with tarfile.open(path) as archive:
        files = [member for member in archive if member.isfile()]
        names = [member.name.split('/', 1)[1] for member in files]
        assert len(names) == len(set(names))
        return {name: archive.extractfile(member).read() for name, member in zip(names, files)}


def test_ast(data):
    tree = ast.parse(data)
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and node.body:
            first = node.body[0]
            if isinstance(first, ast.Expr) and isinstance(first.value, ast.Constant) and isinstance(first.value.value, str):
                node.body.pop(0)
    return ast.dump(tree, include_attributes=False)


def main():
    old_dir, new_dir, output = map(Path, sys.argv[1:])
    old = json.loads((old_dir / 'BUILD_MANIFEST.json').read_text())
    new = json.loads((new_dir / 'BUILD_MANIFEST.json').read_text())
    assert old['source_revision'] == 'b37eec69b7e3e1ba5f980cf44d5befeaa568a049'
    assert new['source_revision'] == 'fc7f9afa8fb63fc7e377f3719571d4d9a64956fa'
    fields = ['version', 'python', 'platform', 'build_dependencies', 'runtime_dependencies', 'module_sha256', 'server_contract', 'inputs', 'negative_controls']
    for field in fields:
        assert old[field] == new[field], field
    for folder, manifest in [(old_dir, old), (new_dir, new)]:
        for name, expected in manifest['artifacts'].items():
            assert digest((folder / name).read_bytes()) == expected, name
    old_wheel_path, new_wheel_path = [next(folder.glob('*.whl')) for folder in (old_dir, new_dir)]
    old_wheel, new_wheel = [wheel_members(path) for path in (old_wheel_path, new_wheel_path)]
    assert old_wheel == new_wheel
    assert digest(new_wheel['uptible_cli/__init__.py']) == new['module_sha256']
    old_source, new_source = [source_members(next(folder.glob('*.tar.gz'))) for folder in (old_dir, new_dir)]
    assert old_source.keys() == new_source.keys()
    changed = sorted(name for name in old_source if old_source[name] != new_source[name])
    assert changed == ['tests/test_contract.py'], changed
    assert new_source[changed[0]] == old_source[changed[0]].split(b'\n', 1)[1]
    test_files = sorted(name for name in old_source if name.startswith('tests/') and name.endswith('.py'))
    for name in test_files:
        assert test_ast(old_source[name]) == test_ast(new_source[name]), name
    schema = 'docs/contracts/v1.1.0.json'
    assert digest(new_source[schema]) == new['server_contract']['sha256']
    receipt = {
        'baseline_head': old['source_revision'],
        'final_head': new['source_revision'],
        'equivalent_manifest_fields': fields,
        'old_artifacts': old['artifacts'],
        'new_artifacts': new['artifacts'],
        'wheel_archive_bytes_identical': old_wheel_path.read_bytes() == new_wheel_path.read_bytes(),
        'all_wheel_member_bytes_identical': True,
        'wheel_metadata_differences': wheel_metadata_changes(old_wheel_path, new_wheel_path),
        'wheel_member_sha256': {name: digest(data) for name, data in sorted(new_wheel.items())},
        'sdist_changed_file_bytes': changed,
        'sdist_change_is_exact_first_line_deletion': True,
        'test_files_with_equivalent_ast_without_docstrings': test_files,
        'module_sha256': new['module_sha256'],
        'contract_sha256': digest(new_source[schema]),
        'native_proof_mapping': 'Every installed wheel member and selected runtime dependency name, version, and input hash is identical to the prior artifact. Prior independent native results remain prior results. This receipt does not claim a new native run.',
    }
    output.write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
