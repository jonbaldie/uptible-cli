# Account email and browser handoff verification

Final source 1d21d1328cd55458c930766141f6db55bc9a3a19. The packaged wheel was installed outside its source checkout, with matching module/artifact hashes. Two independent builds and dependency resolutions produced identical artifacts. The clean-commit gate passed94 tests with1 intentional real-account skip; default tests are synthetic. Tampered dependency/wheel and omitted/broken completion controls were rejected. Six actual interactive Bash/Zsh Tab expansions passed from the installed wheel.

The browser evidence uses disposable synthetic `.test` identities, a separate Chrome test profile, an immutable isolated local app, local SMTP and genuine PKCE/ephemeral-loopback OAuth. No purchase, customer data or provider traffic was involved. An internal-network transport relay was used on this host. The expiration control changes only an owned disposable request timestamp. Password and recipient-code fields were cleared before screenshots.

A pending email request is not an identity update. Real browser recipient confirmation and subsequent API account readback provide the evidence of the change. Browser handoff output deliberately states that opening a page does not confirm the browser account or action completion.

The 72-check installed browser journey used the original b84e299 artifact. Final source changes only the synthetic integration fixture; its installed product module is byte-identical. Both artifact identities are recorded. The final-wheel real opt-in suite passed in 12.864 seconds and interactive completion passed again. This packet does not claim OS keyring/platform acceptance, pinned final schema compatibility, hosted CI acceptance, public distribution or independent review of the entire product.
