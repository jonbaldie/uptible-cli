# Repeat the bounded storage check

Supply the reviewed wheel beside these files. Verify its SHA256 against `provenance.json` before building. The wheel is intentionally not included in the evidence packet.

Build the Docker recipe with a Linux arm64 runtime. Setup downloads OS packages and hash-checked Python dependencies. The requirements are exact committed inputs; OS package resolution is recorded rather than frozen to an archive snapshot.

```sh
sha256sum uptible_cli-0.1.0-py3-none-any.whl
docker build -t uptible-linux-storage-acceptance .
docker run --name uptible-linux-storage-proof --network none --read-only \
  --cap-drop ALL --security-opt no-new-privileges --memory 512m --cpus 1 \
  --tmpfs /tmp:rw,nosuid,nodev,mode=1777,size=32m \
  --tmpfs /home/proof:rw,nosuid,nodev,uid=10001,gid=10001,mode=700,size=32m \
  --mount type=bind,src="$PWD/acceptance.py",dst=/acceptance.py,readonly \
  uptible-linux-storage-acceptance dbus-run-session -- python /acceptance.py
docker inspect uptible-linux-storage-proof
docker rm uptible-linux-storage-proof
docker image rm uptible-linux-storage-acceptance
```

Exit zero and all PASS or NOT_APPLICABLE receipts are required. The script refuses any native backend other than the actual Secret Service backend and rejects internet socket connections. Its D-Bus traffic uses Unix sockets inside the runtime. Each repeat creates new synthetic identities and credentials inside the ephemeral home. Do not mount a host home, credential directory or D-Bus socket.
