import hashlib
import json
import os
from pathlib import Path
import secrets
import signal
import socket
import stat
import subprocess
import sys
import time
import uuid

ROOT = Path.home() / "acceptance"
STATE = ROOT / "state.json"


def receipt(name, **details):
    print(json.dumps({"check": name, "result": "PASS", **details}), flush=True)


def deny_internet(event, args):
    if event == "socket.connect" and args[0].family in (socket.AF_INET, socket.AF_INET6):
        raise AssertionError("Internet socket forbidden in storage acceptance")


sys.addaudithook(deny_internet)


def child(phase, index):
    import keyring
    import uptible_cli
    data = json.loads(STATE.read_text())
    item = data["connections"][index]
    args = item["args"]
    if phase == "no-service":
        try:
            uptible_cli.Store(*args, None)
        except uptible_cli.Failure as exc:
            assert exc.code == "no_credential_store"
        else:
            raise AssertionError("Unavailable native backend accepted")
        receipt("no-service-native-rejected")
        directory = ROOT / "no-service-file"
        directory.mkdir(mode=0o700)
        store = uptible_cli.Store(*args, str(directory / "credentials"))
        with store.lock:
            assert store.load() is None
            store.write(item["value"])
            assert store.load() == item["value"]
            store.delete()
            assert store.load() is None
        receipt("no-service-explicit-file-fallback-save-read-delete")
        return
    store = uptible_cli.Store(*args, None)
    backend = keyring.get_keyring()
    assert type(backend).__module__ == "keyring.backends.SecretService"
    assert type(backend).__name__ == "Keyring"
    assert store.keyring is keyring and store.path is None
    assert Path(uptible_cli.__file__).is_relative_to("/opt/acceptance/")
    assert hashlib.sha256(Path(uptible_cli.__file__).read_bytes()).hexdigest() == "cc2e3a0029ce900690aa50668eef6dc43459f7a05daa2aef28ba38a3d157b10a"
    assert store.identity == item["value"]["identity"]
    with store.lock:
        if phase == "empty":
            assert store.load() is None
        elif phase == "write":
            store.write(item["value"])
            assert store.load() == item["value"]
        elif phase == "read":
            assert store.load() == item["value"]
        elif phase == "replace":
            store.write(item["replacement"])
            assert store.load() == item["replacement"]
        elif phase == "read-replacement":
            assert store.load() == item["replacement"]
        elif phase == "delete":
            store.delete()
            assert store.load() is None
        else:
            raise AssertionError(phase)
    receipt("native-" + phase, connection=index, backend=type(backend).__module__ + "." + type(backend).__name__)


def run_child(phase, index, env=None):
    subprocess.run([sys.executable, __file__, phase, str(index)], check=True, timeout=20, env=env)


def file_checks(data):
    import uptible_cli
    directory = ROOT / "private-file"
    directory.mkdir(mode=0o700)
    path = directory / "credential.json"
    store = uptible_cli.Store(*data["connections"][0]["args"], str(path))
    value = data["connections"][0]["value"]
    assert store.keyring is None
    with store.lock:
        assert store.load() is None
        store.write(value)
        assert store.load() == value
        assert stat.S_IMODE(directory.stat().st_mode) == 0o700
        assert stat.S_IMODE(path.stat().st_mode) == 0o600
        assert stat.S_IMODE(Path(store.lock.lock_file).stat().st_mode) == 0o600
    receipt("file-save-exact-read-private-modes", directory_mode="0700", file_mode="0600", lock_mode="0600")
    other = uptible_cli.Store(*data["connections"][1]["args"], str(path))
    try:
        other.load()
    except uptible_cli.Failure as exc:
        assert exc.code == "wrong_connection"
    else:
        raise AssertionError("Wrong connection accepted file")
    receipt("file-wrong-connection-negative-control")
    path.chmod(0o644)
    try:
        store.load()
    except uptible_cli.Failure as exc:
        assert exc.code == "unsafe_storage"
    else:
        raise AssertionError("Insecure credential mode accepted")
    finally:
        path.chmod(0o600)
    receipt("file-world-readable-negative-control")
    with store.lock:
        store.delete()
        assert store.load() is None and not path.exists()
    receipt("file-delete-absence")
    unsafe = ROOT / "unsafe-file"
    unsafe.mkdir(mode=0o755)
    try:
        uptible_cli.Store(*data["connections"][0]["args"], str(unsafe / "credentials"))
    except uptible_cli.Failure as exc:
        assert exc.code == "unsafe_storage"
    else:
        raise AssertionError("Insecure directory accepted")
    receipt("file-public-directory-negative-control")


def main():
    import platform
    import secretstorage
    import keyring
    ROOT.mkdir(mode=0o700)
    os.environ["XDG_RUNTIME_DIR"] = str(Path.home() / "runtime")
    Path(os.environ["XDG_RUNTIME_DIR"]).mkdir(mode=0o700)
    ident = uuid.uuid4().hex
    base = ["https://" + ident + ".invalid", "client-" + ident, "profile-" + ident]
    tuples = [base, ["https://other-" + ident + ".invalid", *base[1:]], [base[0], "other-" + base[1], base[2]], [*base[:2], "other-" + base[2]]]
    data = {"connections": []}
    for args in tuples:
        identity = hashlib.sha256(json.dumps(args, separators=(",", ":")).encode()).hexdigest()
        value = {"identity": identity, "access_token": secrets.token_urlsafe(32), "refresh_token": secrets.token_urlsafe(32), "expires_at": 4102444800}
        replacement = {**value, "access_token": secrets.token_urlsafe(32), "refresh_token": secrets.token_urlsafe(32)}
        data["connections"].append({"args": args, "value": value, "replacement": replacement})
    STATE.write_text(json.dumps(data))
    STATE.chmod(0o600)
    log = (ROOT / "keyring-daemon.log").open("w+")
    daemon = subprocess.Popen(["gnome-keyring-daemon", "--foreground", "--unlock", "--components=secrets"], stdin=subprocess.PIPE, stdout=log, stderr=log)
    daemon.stdin.write((secrets.token_urlsafe(32) + "\n").encode())
    daemon.stdin.close()
    connection = None
    try:
        deadline = time.monotonic() + 10
        startup_error = None
        while time.monotonic() < deadline:
            try:
                owner = subprocess.run(["dbus-send", "--session", "--dest=org.freedesktop.DBus", "--type=method_call", "--print-reply", "/org/freedesktop/DBus", "org.freedesktop.DBus.NameHasOwner", "string:org.freedesktop.secrets"], capture_output=True, text=True, check=True, timeout=2)
                if "boolean true" not in owner.stdout:
                    time.sleep(0.1)
                    continue
                connection = secretstorage.dbus_init()
                collection = secretstorage.get_default_collection(connection)
                assert not collection.is_locked()
                break
            except Exception as exc:
                startup_error = type(exc).__name__ + ": " + str(exc)
                if connection:
                    connection.close()
                    connection = None
                if daemon.poll() is not None:
                    raise AssertionError("Secret Service daemon exited")
                time.sleep(0.1)
        else:
            log.flush()
            log.seek(0)
            print(json.dumps({"startup_error": startup_error, "daemon_log": log.read()}), flush=True)
            raise AssertionError("Secret Service not available")
        assert list(collection.get_all_items()) == []
        service_pid = subprocess.run(["dbus-send", "--session", "--dest=org.freedesktop.DBus", "--type=method_call", "--print-reply", "/org/freedesktop/DBus", "org.freedesktop.DBus.GetConnectionUnixProcessID", "string:org.freedesktop.secrets"], capture_output=True, text=True, check=True, timeout=2)
        assert service_pid.stdout.splitlines()[-1].strip() == "uint32 " + str(daemon.pid)
        receipt("dbus-service-owned-by-explicit-daemon")
        receipt("isolated-secret-service-ready", platform=platform.system(), architecture=platform.machine(), python=platform.python_version(), backend=type(keyring.get_keyring()).__module__ + "." + type(keyring.get_keyring()).__name__, service="gnome-keyring-daemon", initial_items=0)
        assert len({x["value"]["identity"] for x in data["connections"]}) == 4
        for i in range(4):
            run_child("empty", i)
        for i in range(4):
            run_child("write", i)
            for j in range(i + 1, 4):
                run_child("empty", j)
        assert len(list(collection.get_all_items())) == 4
        receipt("native-service-item-count", items=4)
        for i in range(4):
            run_child("read", i)
        run_child("replace", 0)
        run_child("read-replacement", 0)
        for i in range(1, 4):
            run_child("read", i)
        assert len(list(collection.get_all_items())) == 4
        receipt("replacement-does-not-duplicate-items", items=4)
        for i in range(4):
            run_child("delete", i)
        for i in range(4):
            run_child("empty", i)
        assert list(collection.get_all_items()) == []
        receipt("native-cleanup-all-owned-items-absent", items=0)
        file_checks(data)
        run_child("no-service", 0, {**os.environ, "DBUS_SESSION_BUS_ADDRESS": "unix:path=/home/proof/unavailable-bus"})
        print(json.dumps({"check": "nonpersistent-mode", "result": "NOT_APPLICABLE", "reason": "Current CLI has no nonpersistent credential mode"}), flush=True)
    finally:
        if connection:
            connection.close()
        daemon.terminate()
        try:
            daemon.wait(timeout=5)
        except subprocess.TimeoutExpired:
            daemon.kill()
            daemon.wait(timeout=5)
        assert daemon.poll() is not None
        STATE.unlink(missing_ok=True)
        log.close()
        receipt("owned-daemon-stopped-and-synthetic-state-removed")


if __name__ == "__main__":
    if len(sys.argv) == 3:
        child(sys.argv[1], int(sys.argv[2]))
    else:
        main()
